# EL-JUEGO-DE-ADIVINAR
Mi dirección de github para este repositorio es la siguiente: [GitHub](https://github.com/Germiprogramer/EL-JUEGO-DE-ADIVINAR)
https://github.com/Germiprogramer/EL-JUEGO-DE-ADIVINAR.git

Hemos resuelto un juego de adivinar con valores enteros entre 0 y 99.
El diagrama de flujo que tenemos de nuestro código es el siguiente:

![figma_primer_juego](https://user-images.githubusercontent.com/91720991/140508881-bc58d6a6-8f82-4704-b227-52f3243f4078.jpg)
